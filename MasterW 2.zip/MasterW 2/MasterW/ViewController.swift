//
//  ViewController.swift
//  MasterW
//
//  Created by Sherry on 17/02/2018.
//  Copyright © 2018 Sherry. All rights reserved.
//

import UIKit

class ViewController: UIViewController, MyDelgate {

    @IBOutlet weak var writescoreTextView: UITextView!
    @IBOutlet weak var forceView: UIView!
    @IBOutlet weak var canvasView: CanvasView!
    @IBOutlet weak var BestHWImageView: UIImageView!
    @IBAction func StestButton(_ sender: Any) {
        var matrix = convertPix2Mat()
        var judge = Judgesystem()
        var score = judge.testRating(handwriting: &matrix, option: imagename)
        StestTextView.text = String(score)
//        print(cellWidth,cellHeight)
        print(strokePoints.count)
    }
    @IBOutlet weak var StestTextView: UITextView!
    
    @IBAction func startOver(_ sender: Any) {
    }
    
    var strokePoints = [CGPoint]()
    var cellWidth: Int = 0
    var cellHeight: Int = 0
    var cells : [[Bool]] = []
    
//    var LstrokePoints = [CGPoint]()
//    var LcellWidth: Int = 0
//    var LcellHeight: Int = 0
//    var Lcells : [[Bool]] = []
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        canvasView.clearCanvas(animated:false)
        canvasView.delegate = self
        
        canvasView.backgroundColor = UIColor(white: 1, alpha: 1)
        clickedConfirmHWButtonAction()
        BestHWImageView.backgroundColor = UIColor(white: 1, alpha: 0)
    }
    
    // Shake to clear screen
    
    @IBAction func clearButton(_ sender: UIButton) {
        canvasView.clearCanvas(animated: true)
    }
    func clickedConfirmHWButtonAction(){
        let indicator = 10 * fontsInd + levelInd
        switch indicator {
        case 0:
            imagename = "Bal_let"
            BestHWImageView.image = UIImage(named: imagename)
            break
        case 1:
            imagename = "Bal_word"
            BestHWImageView.image = UIImage(named: imagename)
            break
        case 2:
            imagename = "Bal_sen"
            BestHWImageView.image = UIImage(named: imagename)
            break
        case 10:
            imagename = "Rouge_let"
            BestHWImageView.image = UIImage(named: imagename)
            break
        case 11:
            imagename = "Rouge_word"
            BestHWImageView.image = UIImage(named: imagename)
            break
        case 12:
            imagename = "Rouge_sen"
            BestHWImageView.image = UIImage(named: imagename)
            break
        default:
            break
        }
        BestHWImageView.image = UIImage(named: imagename)
        BestHWImageView.backgroundColor = UIColor(white: 1, alpha: 0)
        //canvasView.addSubview(BestHWImageView)
    }
    //  override func motionEnded(motion: UIEventSubtype, withEvent event: UIEvent?) {
    //    canvasView.clearCanvas(animated: true)
    //  }
    
    func sendData(forceData: Float, strokePoint: CGPoint) {
        self.writescoreTextView?.text = String(forceData)
        
        let forceColor = mixGreenAndRed(greenAmount: (Float(forceData)-0.7)/1.3)
        forceView.backgroundColor = forceColor
        strokePoints.append(strokePoint)
        
    }
    
    func mixGreenAndRed(greenAmount: Float) -> UIColor {
        // the hues between red and green go from 0…1/3, so we can just divide percentageGreen by 3 to mix between them
        return UIColor(hue: CGFloat(greenAmount / 3), saturation: CGFloat(1.0), brightness: CGFloat(1.0), alpha: CGFloat(1.0))
        
    }
    

    
    func convertPix2Mat() -> [[Bool]]{
        self.cellWidth = Int((canvasView.frame.maxX-canvasView.frame.minX)*2)
        self.cellHeight = Int((canvasView.frame.maxY-canvasView.frame.minY)*2)
        self.cells = (Array(repeating: Array(repeating: 0, count: cellWidth), count: cellHeight) as AnyObject) as! [[Bool]]
        
        for point in strokePoints
        {
            var x = Int(Float(point.x)*2)
            var y = Int(Float(point.y)*2)
            if x >= self.cellWidth {x = self.cellWidth-1}
            if x < 0 {x = 0}
            if y >= self.cellHeight {y = self.cellHeight-1}
            if y < 0 {y = 0}
            
            cells[y][x] = true
        }
        
        return cells
    }
    
//    func LetterConvertPix2Mat() -> [[Bool]]{
//        self.LcellWidth = Int((lettercanvasView.frame.maxX-lettercanvasView.frame.minX)*2)
//        self.LcellHeight = Int((lettercanvasView.frame.maxY-lettercanvasView.frame.minY)*2)
//        self.Lcells = (Array(repeating: Array(repeating: 0, count: LcellWidth), count: LcellHeight) as AnyObject) as! [[Bool]]
//        
//        for point in LstrokePoints
//        {
//            var x = Int(Float(point.x)*2)
//            var y = Int(Float(point.y)*2)
//            if x >= self.LcellWidth {x = self.LcellWidth-1}
//            if x < 0 {x = 0}
//            if y >= self.LcellHeight {y = self.LcellHeight-1}
//            if y < 0 {y = 0}
//            
//            Lcells[y][x] = true
//        }
//        
//        return Lcells
//    }
    
    
}

